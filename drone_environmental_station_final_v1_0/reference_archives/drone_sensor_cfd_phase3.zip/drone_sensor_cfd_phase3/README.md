# Drone environmental station CFD — Phase 3

This statically verified repository extension implements the dry particulate-matter stage of the drone sensor enclosure project. It uses a one-way coupled OpenFOAM 14 `kinematicParcelCloud` function object so a converged Phase 1 carrier field can remain frozen while particles are advanced over physical time.

## What is included

- preserved Phase 1 baseline project;
- component-resolved STL generator and snappyHexMesh configuration;
- separate deposition patches for enclosure walls, both tube walls, PM-sensor housing, PM collection face, T–RH sensor, pressure sensor and PCB;
- configurable particle diameters, densities, parcel counts, injection types, gravity, wall interactions and time-step studies;
- characteristic-scale calculations including Cunningham correction, relaxation time, Stokes number, settling and Brownian diffusivity;
- OpenFOAM modular-Lagrangian case templates;
- serial, MPI and HTCondor run scripts;
- a strict parcel-event CSV contract and quantitative post-processing;
- Phase 2 comparison hook without invented Phase 2 data;
- Phase 4 prompt.

## Important limitation

The Phase 2 package does not yet exist. Phase 3 can be run from a converged Phase 1 case, but tracer-versus-particle comparisons are deferred until real Phase 2 CSV outputs are supplied.

## Baseline workflow

```bash
source /opt/openfoam14/etc/bashrc
python3 -m pip install --user -r requirements.txt

# 1. Build/check the component-resolved geometry and templates
python3 phase3_particles/scripts/check_package.py
python3 phase3_particles/geometry/generate_phase3_stl.py

# 2. Keep Phase 1 as the benchmark, then build one component-resolved
#    carrier reference for all Phase 3 particle variants
phase3_particles/scripts/build_carrier_reference.sh

# 3. Generate the requested Phase 3 matrix from that frozen carrier
python3 phase3_particles/scripts/generate_cases.py \
  --carrier-case phase3_particles/carrierReference \
  --profile baseline

# 4. Preflight OpenFOAM 14 runtime selections
phase3_particles/scripts/preflight_openfoam14.sh

# 5. Run one case
phase3_particles/scripts/run_case.sh \
  phase3_particles/generated_cases/mono_continuous_d2p5_rho1500p0_n10000_dt0p01_g1_stick

# 6. Run all generated cases or submit HTCondor jobs
python3 phase3_particles/scripts/run_matrix.py --jobs 1

# 7. Post-process a parcel-event table
python3 phase3_particles/scripts/postprocess_particles.py \
  --events path/to/parcel_events.csv \
  --case-meta path/to/case_metadata.json
```

## Profiles

- `smoke`: minimal cases for installation checks.
- `baseline`: all six diameters, continuous and pulse injection, a weighted polydisperse ensemble manifest, and key sensitivities.
- `full`: baseline plus density, parcel-count, time-step, gravity and wall-model matrices.

## Numerical gate

A case is not accepted as converged unless it meets the thresholds in `config/particles.json`, including fate and mass closure, parcel-count stability and time-step stability.

## Results policy

No numerical PM efficiencies are bundled. Demonstration event files are placed under `schema_examples/` and are explicitly not CFD results.

## Why a Phase 3 carrier reference is built once

Phase 1 used one combined `walls` patch. Component-resolved deposition requires the same physical shape to be remeshed with separate patch names. The carrier is therefore solved once on that topologically relabelled mesh and then frozen and reused by every particle case. This avoids recomputing airflow for each diameter or sensitivity variant.
