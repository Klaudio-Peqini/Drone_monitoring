# Dependencies and current status

## Available in this package

- The original Phase 1 project is preserved under `phase1_baseline/`.
- The uploaded Phase 3 specification is preserved as `PHASE3_PROMPT.md`.
- The generated Phase 4 specification is preserved as `PHASE4_PROMPT.md`.
- A component-resolved Phase 3 geometry, OpenFOAM 14 modular-Lagrangian template, case generator, analysis scripts, HTCondor files and documentation are included.

## Missing upstream dependency

A runnable Phase 2 package was not available when this package was assembled. Therefore:

- Phase 3 preserves Phase 1 as a benchmark but builds one geometrically equivalent component-resolved carrier reference because the original mesh contains a single combined `walls` patch.
- The `compare_phase2.py` script supports a later Phase 2 summary file but does not fabricate one.
- Phase 2 comparisons remain blocked until genuine Phase 2 outputs are supplied.

## Numerical validation status

The package was statically checked in an environment without OpenFOAM 14. The dictionaries are based on the OpenFOAM 14 modular Lagrangian layout, but a target-installation preflight and a real numerical run are mandatory before scientific use.
