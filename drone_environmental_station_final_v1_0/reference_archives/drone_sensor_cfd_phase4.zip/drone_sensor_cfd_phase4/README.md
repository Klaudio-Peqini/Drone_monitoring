# Drone environmental station CFD — Phase 4 package

This package preserves the earlier Phase 1 and Phase 3 repository material and adds Phase 4 thermal, water-vapour and pressure-sensor-bias infrastructure. It also contains the standalone Phase 5 optimization prompt.

## Included

- Phase 1 baseline;
- Phase 2 prompt only;
- Phase 3 dry-particle scaffold;
- Phase 4 analytical screening, geometry, OpenFOAM 14 CHT adapter, case matrix, HTCondor and post-processing;
- Phase 5 prompt.

## Start here

```bash
python3 -m pip install --user -r requirements.txt
./run_phase4_static_checks.sh
```

See `DEPENDENCIES.md` before interpreting status. The package does not claim CFD results that were not executed.