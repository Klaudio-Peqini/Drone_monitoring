#!/usr/bin/env bash
set -euo pipefail
python3 phase3_particles/scripts/check_package.py
python3 phase3_particles/geometry/generate_phase3_stl.py
python3 phase3_particles/scripts/calculate_particle_scales.py
python3 phase3_particles/scripts/postprocess_particles.py --events phase3_particles/schema_examples/parcel_events_demo.csv --case-meta phase3_particles/schema_examples/case_metadata_demo.json --output /tmp/phase3_demo_analysis

# Numerical carrier construction and particle tracking require OpenFOAM 14.
