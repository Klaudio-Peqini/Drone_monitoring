#!/usr/bin/env python3
from pathlib import Path
import json, py_compile, subprocess, sys
root=Path(__file__).resolve().parents[1]
required=['config/particles.json','geometry/generate_phase3_stl.py','baseCase/system/controlDict','baseCase/constant/Lagrangian/pmCloud/LagrangianModels','baseCase/0/Lagrangian/pmCloud/U','scripts/generate_cases.py','scripts/postprocess_particles.py','docs/PHYSICS.md']
missing=[x for x in required if not (root/x).exists()]
if missing: raise SystemExit('Missing: '+', '.join(missing))
json.loads((root/'config/particles.json').read_text())
for p in root.rglob('*.py'): py_compile.compile(str(p),doraise=True)
for p in root.rglob('*.sh'):
 r=subprocess.run(['bash','-n',str(p)]); assert r.returncode==0,p
print('Static package checks passed. OpenFOAM numerical execution not performed.')
