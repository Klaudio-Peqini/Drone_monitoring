#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, math
from pathlib import Path
K_B=1.380649e-23; G=9.81

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='../config/particles.json'); ap.add_argument('--output',default='../results/characteristic_scales.csv'); a=ap.parse_args()
    here=Path(__file__).resolve().parent; cfg=json.loads((here/a.config).resolve().read_text()); out=(here/a.output).resolve(); out.parent.mkdir(parents=True,exist_ok=True)
    air=cfg['air']; geom=cfg['geometry']; U=geom['inlet_velocity_m_s']; D=geom['tube_diameter_m']; tau_box=geom['box_volume_m3']/(geom['flow_rate_L_min']*1e-3/60)
    rows=[]
    for rho in cfg['densities_kg_m3']:
      for du in cfg['diameters_um']:
        d=du*1e-6; lam=air['mean_free_path_m']; Cc=1+(2*lam/d)*(1.257+0.4*math.exp(-1.1*d/(2*lam)))
        tau=rho*d*d*Cc/(18*air['mu_Pa_s']); st=tau*U/D; vs=(rho-air['rho_kg_m3'])*G*d*d*Cc/(18*air['mu_Pa_s'])
        db=K_B*air['temperature_K']*Cc/(3*math.pi*air['mu_Pa_s']*d); pe=U*D/db
        rows.append(dict(diameter_um=du,density_kg_m3=rho,cunningham=Cc,relaxation_time_s=tau,stokes_number=st,settling_velocity_m_s=vs,settling_distance_exchange_m=vs*tau_box,brownian_diffusivity_m2_s=db,particle_peclet=pe,ideal_exchange_time_s=tau_box))
    with out.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    print(out)
if __name__=='__main__': main()
