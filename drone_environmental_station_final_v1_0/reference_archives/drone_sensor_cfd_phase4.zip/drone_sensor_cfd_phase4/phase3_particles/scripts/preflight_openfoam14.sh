#!/usr/bin/env bash
set -euo pipefail
command -v foamRun >/dev/null || { echo "foamRun not found; source OpenFOAM 14 first." >&2; exit 2; }
echo "WM_PROJECT_VERSION=${WM_PROJECT_VERSION:-unknown}"
if [[ "${WM_PROJECT_VERSION:-}" != "14" ]]; then echo "WARNING: package targets Foundation OpenFOAM 14." >&2; fi
foamToC -functionObjects 2>/dev/null | grep -E 'kinematicParcelCloud|cloudPosition|cloudAge|cloudMass' || true
foamInfo kinematicParcelCloud || true
foamInfo SchillerNaumannDrag || true
echo "Preflight completed. Missing selections must be resolved before a run."
