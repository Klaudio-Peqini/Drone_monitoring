#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, math, re, shutil
from pathlib import Path

def token(x): return str(x).replace('.','p').replace('-','m')
def latest_numeric_time(case:Path):
    times=[]
    for p in case.iterdir():
        if p.is_dir():
            try: times.append((float(p.name),p.name))
            except ValueError: pass
    return max(times)[1] if times else '0'
def patch_files(case, repl):
    for p in case.rglob('*'):
        if p.is_file():
            try: t=p.read_text()
            except UnicodeDecodeError: continue
            for k,v in repl.items(): t=t.replace(k,str(v))
            p.write_text(t)
def cases_for(profile,cfg):
    ds=cfg['diameters_um']; rho=cfg['default_density_kg_m3']; n=cfg['default_parcel_count']; dt=cfg['default_time_step_s']; out=[]
    for d in ds:
      for mode in ('continuous','pulse'): out.append(dict(kind='mono',diameter_um=d,density=rho,parcels=n,dt=dt,mode=mode,gravity=True,wall='stick'))
    if profile in ('baseline','full'):
      for d in ds: out.append(dict(kind='mono',diameter_um=d,density=rho,parcels=n,dt=dt,mode='continuous',gravity=False,wall='stick'))
      for d in (0.3,2.5,10.0): out.append(dict(kind='mono',diameter_um=d,density=rho,parcels=n,dt=dt,mode='continuous',gravity=True,wall='rebound'))
    if profile=='full':
      for d in ds:
        for rr in cfg['densities_kg_m3']: out.append(dict(kind='mono',diameter_um=d,density=rr,parcels=n,dt=dt,mode='continuous',gravity=True,wall='stick'))
      for d in (0.3,2.5,10.0):
        for nn in cfg['parcel_counts']: out.append(dict(kind='mono',diameter_um=d,density=rho,parcels=nn,dt=dt,mode='continuous',gravity=True,wall='stick'))
        for dd in cfg['time_steps_s']: out.append(dict(kind='mono',diameter_um=d,density=rho,parcels=n,dt=dd,mode='continuous',gravity=True,wall='stick'))
    # de-duplicate
    seen=set(); uniq=[]
    for c in out:
      key=tuple(sorted(c.items()))
      if key not in seen: seen.add(key); uniq.append(c)
    return uniq

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--carrier-case',required=True); ap.add_argument('--profile',choices=['smoke','baseline','full'],default='baseline'); ap.add_argument('--output',default='../generated_cases'); ap.add_argument('--config',default='../config/particles.json'); a=ap.parse_args()
    here=Path(__file__).resolve().parent; root=here.parent; cfg=json.loads((here/a.config).resolve().read_text()); base=root/'baseCase'; carrier=Path(a.carrier_case).resolve(); out=(here/a.output).resolve(); out.mkdir(parents=True,exist_ok=True)
    ctime=latest_numeric_time(carrier)
    boundary=carrier/'constant/polyMesh/boundary'
    if not (carrier/'constant/polyMesh').exists() or not boundary.exists():
      raise SystemExit('Carrier mesh missing. Run scripts/build_carrier_reference.sh first.')
    if 'enclosureWalls' not in boundary.read_text(errors='ignore'):
      raise SystemExit('Carrier mesh is the Phase 1 single-walls mesh. Build the component-resolved Phase 3 carrier reference first.')
    rows=[]
    selected=cases_for(a.profile,cfg)
    if a.profile=='smoke': selected=selected[:2]
    for i,c in enumerate(selected):
      name=f"{c['kind']}_{c['mode']}_d{token(c['diameter_um'])}_rho{token(c['density'])}_n{c['parcels']}_dt{token(c['dt'])}_g{int(c['gravity'])}_{c['wall']}"
      dest=out/name
      if dest.exists(): shutil.rmtree(dest)
      shutil.copytree(base,dest)
      # Copy the component-resolved mesh and frozen converged carrier time.
      shutil.rmtree(dest/'constant/polyMesh',ignore_errors=True); shutil.copytree(carrier/'constant/polyMesh',dest/'constant/polyMesh')
      src_time=carrier/ctime; dst_time=dest/ctime; dst_time.mkdir(exist_ok=True)
      for field in ('U','p','phi'):
        if (src_time/field).exists(): shutil.copy2(src_time/field,dst_time/field)
      rate=c['parcels']/cfg['end_time_s']
      if c['mode']=='pulse':
        pd=cfg['pulse_duration_s']; rate=c['parcels']/pd
        rate_spec=f"table ((0 {rate}) ({pd} {rate}) ({pd+1e-9} 0) ({cfg['end_time_s']} 0))"
      else: rate_spec=str(rate)
      wall=cfg['wall_models'][c['wall']]; coeff=''
      if c['wall']=='rebound': coeff=f"e {wall['e']}; mu {wall['mu']};"
      number_source='type uniformFixedValue; uniformValue 1;'
      repl={'__DIAMETER_M__':c['diameter_um']*1e-6,'__RHO_RATIO__':c['density']/cfg['air']['rho_kg_m3'],'__NUMBER_RATE__':rate_spec,'__NUMBER_SOURCE__':number_source,'__WALL_BC__':wall['type'],'__REBOUND_COEFFS__':coeff,'__GRAVITY__':f"({0 if not c['gravity'] else cfg['gravity_m_s2'][0]} {0 if not c['gravity'] else cfg['gravity_m_s2'][1]} {0 if not c['gravity'] else cfg['gravity_m_s2'][2]})",'__CARRIER_TIME__':ctime,'__END_TIME__':cfg['end_time_s'],'__DELTA_T__':c['dt'],'__MAX_TIME_FRACTION__':0.3,'__MAX_CELL_FRACTION__':0.3}
      patch_files(dest,repl)
      meta={**c,'case_name':name,'carrier_case':str(carrier),'carrier_time':ctime,'random_seed':cfg['random_seed']+i,'status':'generated_not_run','polydisperse_note':''}
      (dest/'case_metadata.json').write_text(json.dumps(meta,indent=2)); rows.append(meta)
    # In one-way dilute tracking, the six monodisperse continuous runs form an exact
    # non-interacting polydisperse ensemble when combined with configured weights.
    ensemble={'type':'polydisperse_superposition','justification':'one-way dilute particles are independent','members':[]}
    weights=cfg['injection']['polydisperse_number_fractions']
    for r in rows:
      if r['mode']=='continuous' and r['gravity'] and r['wall']=='stick' and r['density']==cfg['default_density_kg_m3']:
        ensemble['members'].append({'case_name':r['case_name'],'diameter_um':r['diameter_um'],'number_fraction':weights.get(str(r['diameter_um']),weights.get(f"{r['diameter_um']:.1f}"))})
    (out/'polydisperse_ensemble.json').write_text(json.dumps(ensemble,indent=2))
    with (out/'case_manifest.csv').open('w',newline='') as f:
      w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    print(f'Generated {len(rows)} cases in {out}')
if __name__=='__main__': main()
