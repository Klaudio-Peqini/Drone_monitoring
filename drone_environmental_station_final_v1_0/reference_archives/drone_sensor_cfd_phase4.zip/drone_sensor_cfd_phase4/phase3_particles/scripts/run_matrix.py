#!/usr/bin/env python3
import argparse, csv, subprocess
from pathlib import Path

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--cases',default='../generated_cases'); ap.add_argument('--jobs',type=int,default=1); a=ap.parse_args(); here=Path(__file__).resolve().parent; cases=(here/a.cases).resolve(); runner=here/'run_case.sh'; statuses=[]
 for case in sorted(p for p in cases.iterdir() if p.is_dir()):
  cp=subprocess.run([str(runner),str(case)]); statuses.append({'case':case.name,'returncode':cp.returncode})
 with (cases/'run_status.csv').open('w',newline='') as f: w=csv.DictWriter(f,fieldnames=['case','returncode']); w.writeheader(); w.writerows(statuses)
if __name__=='__main__': main()
