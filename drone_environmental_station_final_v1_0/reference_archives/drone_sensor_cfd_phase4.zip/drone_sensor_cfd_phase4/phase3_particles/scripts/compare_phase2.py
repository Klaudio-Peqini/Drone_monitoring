#!/usr/bin/env python3
import argparse, pandas as pd

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--phase2',required=True); ap.add_argument('--phase3',required=True); ap.add_argument('--output',required=True); a=ap.parse_args(); s=pd.read_csv(a.phase2); p=pd.read_csv(a.phase3)
 required={'probe','t50_s','t90_s'}
 if not required.issubset(s.columns): raise SystemExit(f'Phase 2 summary must contain {sorted(required)}')
 tracer=s[s.probe.str.contains('pm',case=False,na=False)].head(1)
 if tracer.empty: raise SystemExit('No PM-sensor tracer probe found in Phase 2 summary')
 p['tracer_t50_s']=float(tracer.t50_s.iloc[0]); p['tracer_t90_s']=float(tracer.t90_s.iloc[0]); p['particle_minus_tracer_t50_s']=p.t50_s-p.tracer_t50_s; p['particle_minus_tracer_t90_s']=p.t90_s-p.tracer_t90_s; p.to_csv(a.output,index=False)
if __name__=='__main__': main()
