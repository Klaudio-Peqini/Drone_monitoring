#!/usr/bin/env bash
set -euo pipefail
CASE=${1:?Usage: run_parallel.sh CASE_DIR [N]}; N=${2:-4}; CASE=$(readlink -f "$CASE")
cd "$CASE"; decomposePar -force > log.decomposePar 2>&1
mpirun -np "$N" foamRun -parallel > log.phase3.parallel 2>&1
reconstructPar -latestTime > log.reconstructPar 2>&1
touch PHASE3_RUN_COMPLETE
