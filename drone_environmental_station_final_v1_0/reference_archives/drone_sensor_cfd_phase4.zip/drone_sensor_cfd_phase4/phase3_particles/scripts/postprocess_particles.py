#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib.pyplot as plt
VALID={'inlet_tube_deposited','enclosure_wall_deposited','pm_housing_deposited','sensor_collected','trh_deposited','pressure_deposited','pcb_deposited','outlet_escaped','airborne'}

def wsum(df,mask,col='weight_number'): return float(df.loc[mask,col].sum())
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--events',required=True); ap.add_argument('--case-meta',required=True); ap.add_argument('--output',default=None); a=ap.parse_args(); events=Path(a.events); meta=json.loads(Path(a.case_meta).read_text()); df=pd.read_csv(events)
 req={'parcel_id','diameter_um','density_kg_m3','weight_number','injection_time_s','fate','event_time_s','patch'}; missing=req-set(df.columns)
 if missing: raise SystemExit(f'Missing event columns: {sorted(missing)}')
 bad=set(df.fate)-VALID
 if bad: raise SystemExit(f'Unknown fates: {sorted(bad)}')
 out=Path(a.output) if a.output else Path(a.case_meta).parent/'results'; (out/'csv').mkdir(parents=True,exist_ok=True); (out/'figures').mkdir(parents=True,exist_ok=True)
 rows=[]; dep=[]; arr=[]
 for (d,rho),g in df.groupby(['diameter_um','density_kg_m3']):
  N=float(g.weight_number.sum()); mass_per=math.pi/6*(d*1e-6)**3*rho; M=N*mass_per
  fate={f:wsum(g,g.fate==f) for f in VALID}; closure=sum(fate.values())/N-1 if N else np.nan
  sensor=fate['sensor_collected']/N if N else np.nan; outlet=fate['outlet_escaped']/N if N else np.nan; deposited=sum(v for k,v in fate.items() if k.endswith('deposited'))/N if N else np.nan; airborne=fate['airborne']/N if N else np.nan
  rows.append(dict(case=meta.get('case_name',''),diameter_um=d,density_kg_m3=rho,injected_number=N,injected_mass_kg=M,sensor_efficiency_number=sensor,sensor_efficiency_mass=sensor,outlet_escape_fraction=outlet,total_deposition_fraction=deposited,airborne_fraction=airborne,fate_closure_percent=100*abs(closure)))
  for f,v in fate.items(): dep.append(dict(case=meta.get('case_name',''),diameter_um=d,density_kg_m3=rho,fate=f,number=v,fraction=v/N if N else np.nan))
  s=g[g.fate=='sensor_collected'].copy(); s['arrival_s']=s.event_time_s-s.injection_time_s
  if len(s):
   q=np.quantile(s.arrival_s,[0,.1,.5,.9,.95,1]); arr.append(dict(case=meta.get('case_name',''),diameter_um=d,first_s=q[0],t10_s=q[1],t50_s=q[2],t90_s=q[3],t95_s=q[4],last_s=q[5]))
 pd.DataFrame(rows).to_csv(out/'csv/diameter_efficiencies.csv',index=False); pd.DataFrame(dep).to_csv(out/'csv/surface_deposition.csv',index=False); pd.DataFrame(arr).to_csv(out/'csv/arrival_time_statistics.csv',index=False)
 r=pd.DataFrame(rows)
 if len(r):
  plt.figure(); plt.plot(r.diameter_um,r.sensor_efficiency_number,marker='o'); plt.xlabel('Dry diameter (µm)'); plt.ylabel('PM-sensor collection efficiency'); plt.tight_layout(); plt.savefig(out/'figures/efficiency_vs_diameter.png',dpi=180); plt.close()
 summary={'case':meta.get('case_name',''),'n_rows':len(df),'max_fate_closure_percent':float(r.fate_closure_percent.max()) if len(r) else None,'source_events':str(events)}; (out/'case_summary.json').write_text(json.dumps(summary,indent=2)); print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
