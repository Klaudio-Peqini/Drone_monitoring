#!/usr/bin/env bash
set -euo pipefail
CASE=${1:?Usage: run_case.sh CASE_DIR}
CASE=$(readlink -f "$CASE")
[[ -d "$CASE/constant/polyMesh" ]] || { echo "Missing mesh in $CASE" >&2; exit 3; }
command -v foamRun >/dev/null || { echo "foamRun not found" >&2; exit 2; }
cd "$CASE"
foamDictionary system/controlDict -entry solver -value | grep -q functions || { echo "Not a Phase 3 functions-solver case" >&2; exit 4; }
foamRun > log.phase3 2>&1
if grep -qiE 'FOAM FATAL|Segmentation fault' log.phase3; then echo "FAILED: $CASE" >&2; exit 5; fi
touch PHASE3_RUN_COMPLETE
