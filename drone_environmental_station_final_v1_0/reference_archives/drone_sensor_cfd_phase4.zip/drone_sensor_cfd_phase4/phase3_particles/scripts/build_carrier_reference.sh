#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
ROOT=$(cd "$HERE/.." && pwd)
CASE=${1:-$ROOT/carrierReference}
CASE=$(readlink -m "$CASE")
command -v foamRun >/dev/null || { echo "foamRun not found; source OpenFOAM 14 first." >&2; exit 2; }
rm -rf "$CASE"
cp -a "$ROOT/baseCase" "$CASE"
python3 "$ROOT/geometry/generate_phase3_stl.py" --output "$CASE/constant/triSurface"
cp "$CASE/system/controlDict.carrier" "$CASE/system/controlDict"
cp "$CASE/system/functions.carrier" "$CASE/system/functions"
cd "$CASE"
blockMesh > log.blockMesh 2>&1
surfaceFeatureExtract > log.surfaceFeatureExtract 2>&1
snappyHexMesh -overwrite > log.snappyHexMesh 2>&1
checkMesh -allGeometry -allTopology > log.checkMesh 2>&1
foamRun > log.carrier 2>&1
if grep -qiE 'FOAM FATAL|Segmentation fault' log.*; then
    echo "Carrier construction failed; inspect logs in $CASE" >&2
    exit 5
fi
touch PHASE3_CARRIER_READY
echo "Component-resolved carrier reference created: $CASE"
