#!/usr/bin/env python3
from pathlib import Path
here=Path(__file__).resolve().parent; cases=here.parent/'generated_cases'; out=cases/'condor_queue.txt'; out.write_text('\n'.join(f'{p.name} {p}' for p in sorted(cases.iterdir()) if p.is_dir())+'\n'); print(out)
