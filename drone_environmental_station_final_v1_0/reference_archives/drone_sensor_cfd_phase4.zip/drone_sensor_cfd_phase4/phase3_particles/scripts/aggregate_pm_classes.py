#!/usr/bin/env python3
import argparse, pandas as pd
from pathlib import Path

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--efficiencies',required=True); ap.add_argument('--weights',default='../config/pm_class_weights.csv'); ap.add_argument('--output',required=True); a=ap.parse_args(); here=Path(__file__).resolve().parent; e=pd.read_csv(a.efficiencies); w=pd.read_csv((here/a.weights).resolve()); x=e.merge(w,on='diameter_um',how='left'); out=[]
 for limit,label in [(1.0,'PM1'),(2.5,'PM2.5'),(10.0,'PM10')]:
  q=x[x.diameter_um<=limit].copy(); z=q.number_fraction.sum(); out.append({'class':label,'assumed_weight_sum':z,'sensor_efficiency_number':(q.sensor_efficiency_number*q.number_fraction).sum()/z if z else None,'weighting':'configured inlet number fractions'})
 pd.DataFrame(out).to_csv(a.output,index=False)
if __name__=='__main__': main()
