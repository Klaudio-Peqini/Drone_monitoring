#!/usr/bin/env python3
"""Generate component-resolved, geometrically identical Phase 3 boundaries."""
from __future__ import annotations
import argparse, json, math
from pathlib import Path
from typing import Iterable, Sequence
Vec=tuple[float,float,float]; Tri=tuple[Vec,Vec,Vec]

def normal(a,b,c):
    u=(b[0]-a[0],b[1]-a[1],b[2]-a[2]); v=(c[0]-a[0],c[1]-a[1],c[2]-a[2])
    n=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]); m=math.sqrt(sum(x*x for x in n))
    return (0,0,0) if m==0 else tuple(x/m for x in n)

def write_stl(path, name, tris:Iterable[Tri]):
    with Path(path).open('w',encoding='ascii') as f:
        f.write(f'solid {name}\n')
        for a,b,c in tris:
            n=normal(a,b,c); f.write(f'  facet normal {n[0]:.12e} {n[1]:.12e} {n[2]:.12e}\n    outer loop\n')
            for p in (a,b,c): f.write(f'      vertex {p[0]:.12e} {p[1]:.12e} {p[2]:.12e}\n')
            f.write('    endloop\n  endfacet\n')
        f.write(f'endsolid {name}\n')

def ring(x,r,n): return [(x,r*math.cos(2*math.pi*i/n),r*math.sin(2*math.pi*i/n)) for i in range(n)]
def square_ring(x,h,n):
    out=[]
    for i in range(n):
        t=2*math.pi*i/n; c,s=math.cos(t),math.sin(t); q=h/max(abs(c),abs(s)); out.append((x,q*c,q*s))
    return out

def annulus(inner,outer,pos):
    o=[]; n=len(inner)
    for i in range(n):
        j=(i+1)%n
        o += [(inner[i],outer[i],outer[j]),(inner[i],outer[j],inner[j])] if pos else [(inner[i],outer[j],outer[i]),(inner[i],inner[j],outer[j])]
    return o

def connect(a,b,outward=True):
    o=[]; n=len(a)
    for i in range(n):
        j=(i+1)%n
        o += [(a[i],b[i],b[j]),(a[i],b[j],a[j])] if outward else [(a[i],b[j],b[i]),(a[i],a[j],b[j])]
    return o

def disk(pts,c,pos):
    return [(c,pts[i],pts[(i+1)%len(pts)]) if pos else (c,pts[(i+1)%len(pts)],pts[i]) for i in range(len(pts))]

def box_faces(center,size):
    cx,cy,cz=center; sx,sy,sz=[v/2 for v in size]
    v=[(cx-sx,cy-sy,cz-sz),(cx+sx,cy-sy,cz-sz),(cx+sx,cy+sy,cz-sz),(cx-sx,cy+sy,cz-sz),(cx-sx,cy-sy,cz+sz),(cx+sx,cy-sy,cz+sz),(cx+sx,cy+sy,cz+sz),(cx-sx,cy+sy,cz+sz)]
    solid={
      'xMin':[(0,4,7),(0,7,3)], 'xMax':[(1,2,6),(1,6,5)],
      'yMin':[(0,1,5),(0,5,4)], 'yMax':[(3,7,6),(3,6,2)],
      'zMin':[(0,3,2),(0,2,1)], 'zMax':[(4,5,6),(4,6,7)]}
    # reverse solid outward triangles to normals directed out of fluid, into obstacle
    return {k:[(v[a],v[c],v[b]) for a,b,c in faces] for k,faces in solid.items()}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',default='../../phase1_baseline/config/geometry.json'); ap.add_argument('--output',default='../baseCase/constant/triSurface'); a=ap.parse_args()
    here=Path(__file__).resolve().parent; cfg=json.loads((here/a.config).resolve().read_text()); out=(here/a.output).resolve(); out.mkdir(parents=True,exist_ok=True)
    L=cfg['box']['length_x']; h=cfg['box']['width_y']/2; r=cfg['tube']['internal_diameter']/2; Lt=cfg['tube']['external_length']; n=int(cfg['tube']['circle_segments'])
    i0,iL,o0,oL,ri,ro=ring(0,r,n),ring(L,r,n),square_ring(0,h,n),square_ring(L,h,n),ring(-Lt,r,n),ring(L+Lt,r,n)
    surfaces={
      'enclosureWalls':annulus(i0,o0,False)+annulus(iL,oL,True)+connect(o0,oL,False),
      'inletTubeWalls':connect(ri,i0,True), 'outletTubeWalls':connect(iL,ro,True),
      'inlet':disk(ri,(-Lt,0,0),False), 'outlet':disk(ro,(L+Lt,0,0),True)}
    names={'pm_sensor':'pmSensor','temperature_humidity':'trhSensor','pressure_sensor':'pressureSensor','pcb':'pcb'}
    for key,item in cfg['sensors'].items():
        faces=box_faces(item['center'],item['size'])
        if key=='pm_sensor':
            surfaces['pmSensorCollection']=faces.pop('xMin')
            surfaces['pmSensorHousing']=sum(faces.values(),[])
        else: surfaces[names[key]]=sum(faces.values(),[])
    for name,tris in surfaces.items(): write_stl(out/f'{name}.stl',name,tris)
    summary={'surfaces':{k:len(v) for k,v in surfaces.items()},'combined_watertight':'not_checked'}
    try:
        import trimesh
        meshes=[trimesh.load_mesh(str(out/f'{k}.stl'),process=False) for k in surfaces]
        merged=trimesh.util.concatenate(meshes); merged.merge_vertices(); summary.update(combined_watertight=bool(merged.is_watertight),combined_components=len(merged.split(only_watertight=False)),euler_number=int(merged.euler_number))
    except Exception as e: summary['topology_check']=f'skipped: {e}'
    (out/'phase3_geometry_summary.json').write_text(json.dumps(summary,indent=2)); print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
