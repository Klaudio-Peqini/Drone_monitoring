# ParaView workflow

1. Open the generated case with `paraFoam`.
2. Load the `pmCloud` Lagrangian data and enable position, diameter, age and velocity arrays.
3. Colour trajectories by `d`, then by age.
4. Display component patches individually to distinguish tube, enclosure, PCB and sensor deposition.
5. Use `pmSensorCollection` and `outlet` as the principal collection/escape surfaces.
6. Use Temporal Statistics only after confirming the time directory sequence and parcel weighting.
7. Never interpret one displayed parcel as one physical particle unless `number=1`.
