# Parcel-event export adapter

The analysis scripts consume `parcel_events.csv` with the schema in `config/event_schema.csv`. OpenFOAM writes cloud fields and flux/distribution outputs, but a single component-resolved fate ledger is installation- and model-dependent.

Before scientific production, implement and verify one of these adapters on the target v14 installation:

1. a modular-Lagrangian cloud function object that records injection and patch interaction events;
2. a post-processing adapter combining cloud position/age/number fields with component patches and cloud flux fields;
3. a validated custom library.

The package does not fabricate this ledger. The schema example is only a unit test for downstream metrics.
