# Numerical verification

Required gates:

1. Fate closure and injected mass closure below 0.5%.
2. Relative change in collection efficiency below 2% between the two largest parcel populations.
3. Relative change below 2% between the two smallest time steps.
4. Repeatability under a fixed seed.
5. Serial/MPI agreement within statistical uncertainty.
6. Stable ranking of component deposition fractions.
7. Local mesh sensitivity around the inlet and PM collection face.

The package flags absent or malformed fate tables; it never substitutes synthetic efficiencies.
