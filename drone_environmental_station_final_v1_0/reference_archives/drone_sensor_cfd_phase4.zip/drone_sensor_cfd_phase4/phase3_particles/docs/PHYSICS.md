# Phase 3 physical model

## Carrier and coupling

The baseline uses a frozen converged incompressible laminar carrier field solved once on a geometrically identical mesh whose wall patch is split by component for deposition accounting. A function-object `kinematicParcelCloud` is one-way coupled: drag and gravity act on parcels, but parcel reaction forces are not applied to air.

A two-way calculation should be reconsidered only if estimated particulate mass or volume loading is no longer dilute, or if a sensitivity run shows a non-negligible carrier momentum source.

## Parcel interpretation

A parcel is a computational element representing one or more identical spherical physical particles. The `number` field is the statistical weight. Number- and mass-weighted quantities are both retained in the event schema.

## Diameter and density

The configured diameter is treated as dry geometric diameter. Reported PM classes are aerodynamic classes. Converting between them requires particle density and dynamic shape factor; the baseline spherical approximation sets the shape factor to one and records density explicitly.

## Forces

The OpenFOAM baseline template enables Schiller–Naumann drag and gravity. Added mass, pressure-gradient force and Saffman lift are disabled because the target particles are much denser than air and the reference flow is slow; this remains a testable assumption.

## Slip and Brownian motion

`calculate_particle_scales.py` computes the Cunningham factor, Brownian diffusivity and Péclet number. Runtime slip/Brownian implementation is deliberately a compatibility gate rather than an unverified claim: use `foamInfo`/`foamToC` on the exact OpenFOAM 14 installation and add a tested model or custom extension before accepting the 0.3–1 µm bins as final.

## Wall interactions

The baseline uses perfect sticking. Rebound coefficients in the sensitivity model are deliberately provisional and cannot be calibrated from CFD alone.

## PM collection surface

The entire upstream face of the simplified PM block is named `pmSensorCollection`. This is a geometric proxy, not a model of the internal optical sensor or fan. Later CAD and bench calibration must replace it.

## Polydisperse implementation

Because the baseline is dilute and one-way coupled, diameter classes do not interact. The package therefore represents a polydisperse aerosol as a weighted superposition of the six monodisperse continuous runs. `polydisperse_ensemble.json` records the members and inlet number fractions. Under these assumptions this is equivalent to injecting all classes in one run, while making convergence and attribution clearer.
