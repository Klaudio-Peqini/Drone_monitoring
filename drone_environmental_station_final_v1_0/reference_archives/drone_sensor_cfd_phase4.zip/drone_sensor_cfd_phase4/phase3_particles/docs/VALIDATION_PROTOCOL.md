# Experimental validation preparation

Measure simultaneously:

- upstream size-resolved number concentration with a reference counter;
- candidate PM-sensor output;
- inlet/outlet volumetric flow;
- temperature and relative humidity;
- test-aerosol composition and density;
- repeated runs for uncertainty and drift.

Wall sticking, rebound, true size distribution and losses inside the commercial PM sensor require empirical calibration. Smoke visualization alone is not a quantitative PM calibration.
