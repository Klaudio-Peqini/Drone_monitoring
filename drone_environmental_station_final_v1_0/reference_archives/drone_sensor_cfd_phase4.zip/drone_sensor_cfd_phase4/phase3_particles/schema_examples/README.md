# Schema example only

`parcel_events_demo.csv` is artificial test data for checking the post-processor. It is not a CFD result.
