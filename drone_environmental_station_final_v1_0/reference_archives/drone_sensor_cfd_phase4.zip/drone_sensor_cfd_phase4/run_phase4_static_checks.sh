#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd)
python3 "$ROOT/phase4_thermal_humidity_pressure/scripts/generate_case_matrix.py"
python3 "$ROOT/phase4_thermal_humidity_pressure/scripts/calculate_screening.py"
python3 "$ROOT/phase4_thermal_humidity_pressure/geometry/generate_phase4_stl.py"
python3 "$ROOT/phase4_thermal_humidity_pressure/scripts/prepare_cases.py"
python3 "$ROOT/phase4_thermal_humidity_pressure/scripts/make_condor_queue.py"
python3 "$ROOT/phase4_thermal_humidity_pressure/scripts/check_package.py"
