# Dependencies and validation status

- Phase 1: statically verified baseline; numerical execution remains user-side.
- Phase 2: prompt exists, runnable package does not yet exist.
- Phase 3: statically verified implementation scaffold; numerical particle results do not yet exist.
- Phase 4: statically verified framework and analytical screening; CHT runtime adapter and numerical validation require an OpenFOAM 14 installation.

Python: numpy, pandas, matplotlib and trimesh. Runtime: OpenFOAM Foundation 14 and an official installed CHT tutorial.