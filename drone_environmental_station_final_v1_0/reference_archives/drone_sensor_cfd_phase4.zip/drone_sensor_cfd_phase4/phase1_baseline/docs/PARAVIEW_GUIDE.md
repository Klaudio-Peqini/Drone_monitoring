# ParaView post-processing

Run `paraFoam -case case` from the project root and click **Apply**.

1. **Velocity magnitude:** use `Calculator`, set result to `Umag`, expression `mag(U)`, then display a central `Slice` at `z=0` and another at `y=0`.
2. **Streamlines:** add `Stream Tracer`; use a line source across the inlet disk near `x=-0.039 m`, integrate forward, and colour by `Umag`.
3. **Pressure:** colour the central slices by `p`. Multiply kinematic pressure by `rho=1.204 kg/m³` for Pa.
4. **Recirculation:** on the `y=0` and `z=0` slices, apply `Glyph` to velocity vectors. Reverse-flow vectors and closed streamlines identify recirculation.
5. **Stagnant zones:** apply `Threshold` to `Umag` with range `0–0.02 m/s`. The Python post-processor computes the corresponding volume fraction.
6. **Short-circuiting:** inspect inlet-seeded streamlines. A narrow path going directly to the outlet while bypassing most of the box indicates short-circuiting.
7. **Sensors:** load `constant/triSurface/walls.stl` separately if a clear obstacle outline is required.

Export standard screenshots to `results/figures/`: `velocity_midplane.png`, `streamlines.png`, `pressure_midplane.png`, and `low_speed_regions.png`.
