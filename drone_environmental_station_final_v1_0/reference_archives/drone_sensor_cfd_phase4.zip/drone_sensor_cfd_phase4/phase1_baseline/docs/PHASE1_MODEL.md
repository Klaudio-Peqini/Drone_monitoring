# Phase 1 model definition

## Coordinate system

- `x`: inlet-to-outlet direction.
- `y`: lateral direction.
- `z`: vertical direction.
- Box interior: `0 <= x <= 0.150 m`, `-0.075 <= y,z <= 0.075 m`.
- Inlet tube: `-0.040 <= x <= 0 m`.
- Outlet tube: `0.150 <= x <= 0.190 m`.

## Baseline assumptions

1. Air is Newtonian, incompressible and isothermal at approximately 20 °C.
2. Kinematic viscosity is `1.50e-5 m²/s`; density is used only to convert kinematic pressure to Pa.
3. Uniform plug velocity is imposed at the inlet. The outlet has fixed zero kinematic pressure.
4. All enclosure, tube and obstacle surfaces are smooth, impermeable, stationary no-slip walls.
5. Sensors and PCB are simplified impermeable rectangular blocks; no internal sensor flow is represented yet.
6. Tube wall thickness and external enclosure wall thickness do not affect the fluid domain and are omitted.
7. Gravity is irrelevant to this isothermal single-phase airflow phase.
8. Flow is steady and laminar at the reference condition.

## Derived quantities at 2 L/min

- Volume flow: `3.333333e-5 m³/s`.
- Tube area: `7.853982e-5 m²`.
- Mean inlet speed: `0.424413 m/s`.
- Tube Reynolds number: approximately `283`.
- Ideal box exchange time, ignoring obstruction volume: approximately `101.25 s`.

## Solver

OpenFOAM 14 `foamRun` with `solver incompressibleFluid` and SIMPLE steady-state coupling is used. This modular solver supports steady incompressible isothermal flow. The laminar momentum-transport model is selected because the tube Reynolds number is far below the conventional transition range.

## Mesh design

`blockMesh` creates a 5 mm Cartesian background mesh. `snappyHexMesh` retains the fluid region enclosed by the STL surfaces and removes the four internal solid blocks. Refinement produces approximately:

- 2.5 mm cells in the box core;
- 1.25 mm cells around the tube regions;
- down to about 0.625 mm adjacent to geometry surfaces and sharp features.

This gives about 16 cells across the 10 mm tube diameter at the finest surface level. A formal mesh-independence study remains a mandatory validation step before design conclusions.

## Acceptance criteria

- `checkMesh` completes without failed topology/geometry checks.
- No negative-volume cells.
- Recommended maximum non-orthogonality below 65°.
- Final residuals: `U < 1e-7`, `p < 1e-6`.
- Absolute inlet/outlet flow mismatch below 0.1%.
- Flow and pressure-drop values vary by less than 0.1% over the final 100 iterations.
- Coarse, medium and fine meshes should change pressure drop and principal probe velocities by less than 2%; the low-speed volume fraction should change by less than 5% relative.
