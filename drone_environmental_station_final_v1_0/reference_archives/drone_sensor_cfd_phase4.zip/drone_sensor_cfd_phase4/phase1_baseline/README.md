# Drone sensor enclosure CFD — Phase 1

A reproducible OpenFOAM 14 baseline for steady, incompressible, isothermal airflow through a `150 × 150 × 150 mm` drone-mounted environmental-sensor enclosure with opposite 10 mm-ID tubes and simplified internal sensor/PCB obstacles.

## What is included

- Pure-Python parametric STL generation; no CAD package is required.
- OpenFOAM `blockMesh` + `snappyHexMesh` workflow.
- Steady laminar `incompressibleFluid` case.
- Automatic 2 L/min inlet-speed and Reynolds-number calculation.
- Flow-rate, pressure and sensor-probe function objects.
- VTK/PyVista quantitative post-processing and CSV/JSON summaries.
- Local, MPI and HTCondor launch scripts.
- ParaView and model-definition documentation.
- A ready-to-use Phase 2 prompt.

## Baseline physics

At 2 L/min through a 10 mm-ID tube:

- `Q = 3.333333e-5 m³/s`
- `U_in = 0.424413 m/s`
- `Re ≈ 283`

The flow is therefore modeled as laminar. OpenFOAM 14 uses `foamRun` with `solver incompressibleFluid` for steady incompressible isothermal flow.

## Installation

Ubuntu package installation for the OpenFOAM Foundation release:

```bash
sudo apt update
sudo apt install openfoam14 paraview python3 python3-pip
source /opt/openfoam14/etc/bashrc   # path may differ by package installation
python3 -m pip install --user -r requirements.txt
```

OpenFOAM 14 packages are available for Ubuntu 22.04, 24.04 and 26.04. If OpenFOAM is installed elsewhere, source its `etc/bashrc` before running.

## Run the static checks

These checks generate the STL files, validate JSON and update the inlet speed without requiring OpenFOAM:

```bash
python3 scripts/check_package.py
```

Inspect `case/constant/triSurface/geometry_summary.json`. The combined surface should report `combined_watertight: true` when `trimesh` is installed.

## Run locally

```bash
source /opt/openfoam14/etc/bashrc
./scripts/run_case.sh
```

Main outputs:

- `case/log.blockMesh`
- `case/log.snappyHexMesh`
- `case/log.checkMesh`
- `case/log.foamRun`
- `case/postProcessing/`
- `results/csv/phase1_summary.csv`
- `results/csv/phase1_summary.json`

## Run with MPI

```bash
source /opt/openfoam14/etc/bashrc
./scripts/run_parallel.sh 8
```

The default `decomposeParDict` uses Scotch. Start with 4–8 ranks; this baseline mesh is not large enough to benefit from excessive parallelism.

## Run through HTCondor

The working directory must be on a shared filesystem visible from worker nodes, and the OpenFOAM environment must be available through the submitted environment.

```bash
cd htcondor
condor_submit openfoam_phase1.sub
```

Adjust `request_cpus`, memory, arguments and environment sourcing to match the University cluster. For installations not automatically exported to batch jobs, create a site-specific wrapper that sources OpenFOAM before calling `scripts/run_parallel.sh`.

## Change geometry or flow

Edit `config/geometry.json`, then rerun `scripts/run_case.sh`. The geometry generator and inlet-speed calculator are executed automatically. Keep sensor blocks fully inside the enclosure and do not overlap them.

## Quantitative outputs

The summary includes:

- signed and absolute inlet/outlet volume flow;
- flow-balance error;
- mean inlet and outlet kinematic pressure;
- pressure drop converted to Pa;
- volume-weighted mean and maximum speed;
- volume fraction below `0.02 m/s`;
- speed and pressure at sensor-adjacent probes when probe data are available.

`pyvista` is required for mesh-volume velocity statistics. Flow, pressure and probes are still recorded by OpenFOAM function objects without PyVista.

## Convergence and validation

Do not accept a design merely because the solver terminates. Require:

1. `checkMesh` without failed checks or negative volumes.
2. `U < 1e-7` and `p < 1e-6` residual criteria.
3. inlet/outlet flow mismatch below 0.1%.
4. stable flow and pressure-drop histories over the final 100 iterations.
5. a three-level mesh study before reporting final engineering values.
6. experimental comparison with tube velocity and smoke-flow patterns before Phase 2 conclusions are treated as validated.

## Troubleshooting

- **`foamRun: command not found`:** source the OpenFOAM 14 `etc/bashrc` file.
- **`Cannot find patch inlet/outlet/walls`:** inspect `log.snappyHexMesh` and `constant/polyMesh/boundary`; confirm all three STL files exist.
- **snappy keeps the wrong region:** confirm `locationInMesh` lies in air and outside every obstacle.
- **mesh not watertight:** rerun `python3 geometry/generate_stl.py`; inspect the topology report and do not manually edit the STL files.
- **solver divergence:** inspect mesh quality, reduce relaxation factors to 0.6, initialize with `potentialFoam`, or temporarily use first-order `bounded Gauss upwind` for `div(phi,U)`.
- **no VTK statistics:** install PyVista and run `foamToVTK -case case -latestTime -fields '(U p)'`, then rerun `scripts/postprocess.py --skip-vtk-conversion`.

## Directory structure

```text
config/                 geometry and flow parameters
geometry/               parametric STL generator
case/0/                 velocity and pressure fields
case/constant/           air properties, laminar model, STL surfaces
case/system/             mesh, solver and sampling dictionaries
scripts/                 local/MPI run, cleanup and post-processing
htcondor/                batch submission example
docs/                    model and ParaView guidance
results/                 CSV, JSON and exported figures
PHASE2_PROMPT.md          next-phase instruction
```

See `docs/PHASE1_MODEL.md` for assumptions and acceptance criteria, and `docs/PARAVIEW_GUIDE.md` for visualization steps.
