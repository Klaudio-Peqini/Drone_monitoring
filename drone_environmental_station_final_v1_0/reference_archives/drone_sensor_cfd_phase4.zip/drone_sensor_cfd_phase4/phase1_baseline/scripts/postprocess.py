#!/usr/bin/env python3
"""Create a one-row Phase 1 summary CSV from OpenFOAM outputs.

The script parses function-object tables and, when PyVista is available,
reads foamToVTK output to compute volume-weighted velocity statistics and the
low-speed volume fraction.
"""
from __future__ import annotations
import argparse, csv, json, math, re, subprocess
from pathlib import Path
from typing import Optional


def latest_data_file(base: Path) -> Optional[Path]:
    files = [p for p in base.rglob('*.dat') if p.is_file()]
    if not files: return None
    def key(p):
        try: return float(p.parent.name)
        except ValueError: return -1.0
    return max(files, key=key)


def last_numeric_row(path: Optional[Path]) -> Optional[list[float]]:
    if path is None: return None
    rows=[]
    for line in path.read_text(errors='ignore').splitlines():
        if not line.strip() or line.lstrip().startswith('#'): continue
        vals=[]
        for token in line.replace('(',' ').replace(')',' ').split():
            try: vals.append(float(token))
            except ValueError: pass
        if vals: rows.append(vals)
    return rows[-1] if rows else None


def function_value(case: Path, name: str) -> Optional[float]:
    row=last_numeric_row(latest_data_file(case/'postProcessing'/name))
    return row[-1] if row and len(row)>=2 else None


def vtk_stats(case: Path, threshold: float):
    try:
        import numpy as np
        import pyvista as pv
    except Exception as exc:
        return {'vtk_status': f'PyVista unavailable: {exc}'}
    candidates=[]
    for ext in ('*.vtu','*.vtk','*.pvtu'):
        candidates += list((case/'VTK').rglob(ext))
    candidates=[p for p in candidates if 'boundary' not in str(p).lower()]
    if not candidates:
        return {'vtk_status':'No volume VTK file found'}
    volume=max(candidates, key=lambda p:p.stat().st_mtime)
    mesh=pv.read(volume)
    if hasattr(mesh,'combine'): mesh=mesh.combine()
    if 'U' in mesh.point_data and 'U' not in mesh.cell_data:
        mesh=mesh.point_data_to_cell_data(pass_point_data=True)
    if 'U' not in mesh.cell_data:
        return {'vtk_status':f'U not found in cell data of {volume}'}
    U=np.asarray(mesh.cell_data['U'])
    speed=np.linalg.norm(U,axis=1)
    sized=mesh.compute_cell_sizes(length=False, area=False, volume=True)
    vol=np.asarray(sized.cell_data['Volume'])
    good=np.isfinite(speed)&np.isfinite(vol)&(vol>0)
    speed,vol=speed[good],vol[good]
    total=vol.sum()
    return {
        'vtk_status':'ok', 'vtk_file':str(volume.relative_to(case)),
        'mean_velocity_volume_weighted_m_s':float((speed*vol).sum()/total),
        'max_velocity_m_s':float(speed.max()),
        'low_speed_threshold_m_s':threshold,
        'low_speed_volume_fraction':float(vol[speed<threshold].sum()/total),
        'fluid_volume_from_mesh_m3':float(total)
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--case',default='case')
    ap.add_argument('--config',default='config/geometry.json')
    ap.add_argument('--skip-vtk-conversion',action='store_true')
    args=ap.parse_args()
    root=Path(__file__).resolve().parents[1]
    case=(root/args.case).resolve()
    cfg=json.loads((root/args.config).read_text())
    if not args.skip_vtk_conversion and not (case/'VTK').exists():
        try:
            subprocess.run(['foamToVTK','-case',str(case),'-latestTime','-fields','(U p)'],check=True)
        except Exception as exc:
            print(f'Warning: foamToVTK failed: {exc}')

    qin=function_value(case,'inletFlowRate')
    qout=function_value(case,'outletFlowRate')
    pin=function_value(case,'inletPressure')
    pout=function_value(case,'outletPressure')
    rho=float(cfg['flow']['air_density_kg_m3'])
    rec={
        'case':case.name,
        'inlet_flux_signed_m3_s':qin,
        'outlet_flux_signed_m3_s':qout,
        'inlet_flow_abs_m3_s':abs(qin) if qin is not None else None,
        'outlet_flow_abs_m3_s':abs(qout) if qout is not None else None,
        'inlet_pressure_kinematic_m2_s2':pin,
        'outlet_pressure_kinematic_m2_s2':pout,
        'pressure_drop_Pa':rho*(pin-pout) if pin is not None and pout is not None else None,
    }
    if qin is not None and qout is not None:
        denom=max(abs(qin),abs(qout),1e-30)
        rec['mass_balance_error_percent']=100*abs(abs(qin)-abs(qout))/denom
    rec.update(vtk_stats(case,float(cfg['low_speed_threshold_m_s'])))

    probe_names=list(cfg['probes'])
    for field in ('U','p'):
        pf=latest_data_file(case/'postProcessing'/'sensorProbes')
        # OpenFOAM normally writes U and p into separate files in the same folder.
        candidates=list((case/'postProcessing'/'sensorProbes').rglob(field)) + list((case/'postProcessing'/'sensorProbes').rglob(field+'.dat'))
        if candidates:
            row=last_numeric_row(max(candidates,key=lambda p:p.stat().st_mtime))
            if row:
                vals=row[1:]
                if field=='p':
                    for name,val in zip(probe_names,vals): rec[f'p_{name}_kinematic']=val
                else:
                    for i,name in enumerate(probe_names):
                        j=3*i
                        if j+2<len(vals):
                            ux,uy,uz=vals[j:j+3]
                            rec[f'U_{name}_m_s']=math.sqrt(ux*ux+uy*uy+uz*uz)

    out=root/'results/csv/phase1_summary.csv'
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rec))
        w.writeheader(); w.writerow(rec)
    (root/'results/csv/phase1_summary.json').write_text(json.dumps(rec,indent=2))
    print(json.dumps(rec,indent=2))
    print(f'Wrote {out}')

if __name__=='__main__': main()
