#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CASE="$ROOT/case"
rm -rf "$CASE/constant/polyMesh" "$CASE/postProcessing" "$CASE/VTK" "$CASE"/processor* "$CASE"/[1-9]*
rm -f "$CASE"/log.* "$ROOT/results/csv/phase1_summary."{csv,json}
echo "Case cleaned; geometry STL files retained."
