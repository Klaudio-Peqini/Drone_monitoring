#!/usr/bin/env python3
"""Static package checks that do not require OpenFOAM."""
from pathlib import Path
import json, subprocess, sys
root=Path(__file__).resolve().parents[1]
required=[
 'config/geometry.json','geometry/generate_stl.py','case/0/U','case/0/p',
 'case/constant/physicalProperties','case/constant/momentumTransport',
 'case/system/blockMeshDict','case/system/snappyHexMeshDict',
 'case/system/controlDict','case/system/fvSchemes','case/system/fvSolution',
 'scripts/run_case.sh','scripts/postprocess.py','README.md'
]
missing=[p for p in required if not (root/p).exists()]
if missing: raise SystemExit('Missing files: '+', '.join(missing))
json.loads((root/'config/geometry.json').read_text())
subprocess.run([sys.executable,str(root/'geometry/generate_stl.py')],check=True)
subprocess.run([sys.executable,str(root/'scripts/calculate_flow.py')],check=True)
print('Static package checks passed.')
