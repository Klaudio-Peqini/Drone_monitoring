#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CASE="$ROOT/case"

load_openfoam() {
    command -v foamRun >/dev/null 2>&1 && return 0
    for rc in \
        /opt/openfoam14/etc/bashrc \
        /usr/lib/openfoam/openfoam14/etc/bashrc \
        "$HOME/OpenFOAM/OpenFOAM-14/etc/bashrc"; do
        if [[ -f "$rc" ]]; then
            # shellcheck disable=SC1090
            source "$rc"
            command -v foamRun >/dev/null 2>&1 && return 0
        fi
    done
    echo "ERROR: OpenFOAM 14 environment not found. Source etc/bashrc first." >&2
    exit 2
}
load_openfoam

cd "$ROOT"
python3 geometry/generate_stl.py
python3 scripts/calculate_flow.py
cd "$CASE"
rm -rf constant/polyMesh 1 2 3 4 5 6 7 8 9 [1-9][0-9]* processor* postProcessing VTK

blockMesh > log.blockMesh 2>&1
surfaceFeatureExtract > log.surfaceFeatureExtract 2>&1
snappyHexMesh -overwrite > log.snappyHexMesh 2>&1
checkMesh -allGeometry -allTopology > log.checkMesh 2>&1
if grep -q "Failed" log.checkMesh; then
    echo "ERROR: checkMesh reported a failure. Inspect case/log.checkMesh." >&2
    exit 3
fi

foamRun > log.foamRun 2>&1
foamToVTK -latestTime -fields '(U p)' > log.foamToVTK 2>&1 || true
cd "$ROOT"
python3 scripts/postprocess.py --skip-vtk-conversion

echo "Phase 1 complete. Open case in ParaView with: paraFoam -case $CASE"
