#!/usr/bin/env python3
"""Calculate flow quantities and update the inlet velocity in case/0/U."""
from __future__ import annotations
import argparse, json, math, re
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument('--config', default='config/geometry.json')
ap.add_argument('--case', default='case')
args = ap.parse_args()
root = Path(__file__).resolve().parents[1]
cfg = json.loads((root/args.config).read_text())
case = root/args.case
Q_lpm = float(cfg['flow']['rate_L_min'])
Q = Q_lpm*1e-3/60.0
D = float(cfg['tube']['internal_diameter'])
A = math.pi*D**2/4.0
U = Q/A
nu = float(cfg['flow']['kinematic_viscosity_m2_s'])
rho = float(cfg['flow']['air_density_kg_m3'])
Re = U*D/nu
mu = rho*nu
Lt = float(cfg['tube']['external_length'])
dp_one_tube = 128*mu*Lt*Q/(math.pi*D**4)
exchange_time = (cfg['box']['length_x']*cfg['box']['width_y']*cfg['box']['height_z'])/Q

u_file = case/'0/U'
text = u_file.read_text()
text, count = re.subn(r'(// INLET_VELOCITY_BEGIN\s*\n\s*value\s+uniform\s+)\([^;]+\)(;\s*\n\s*// INLET_VELOCITY_END)',
                      rf'\g<1>({U:.12g} 0 0)\g<2>', text)
if count != 1:
    raise RuntimeError('Could not uniquely update inlet velocity markers in case/0/U')
u_file.write_text(text)

derived = {
    'flow_rate_L_min': Q_lpm, 'flow_rate_m3_s': Q,
    'tube_area_m2': A, 'mean_inlet_velocity_m_s': U,
    'kinematic_viscosity_m2_s': nu, 'dynamic_viscosity_Pa_s': mu,
    'air_density_kg_m3': rho, 'tube_Reynolds_number': Re,
    'flow_regime': 'laminar' if Re < 2300 else ('transitional' if Re < 4000 else 'turbulent'),
    'ideal_box_exchange_time_s': exchange_time,
    'poiseuille_pressure_drop_one_40mm_tube_Pa': dp_one_tube,
    'poiseuille_pressure_drop_two_tubes_Pa': 2*dp_one_tube
}
(root/'config/derived_flow.json').write_text(json.dumps(derived, indent=2))
print(json.dumps(derived, indent=2))
