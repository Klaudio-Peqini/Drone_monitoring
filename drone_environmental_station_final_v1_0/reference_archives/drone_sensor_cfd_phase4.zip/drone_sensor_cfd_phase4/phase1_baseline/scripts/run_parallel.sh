#!/usr/bin/env bash
set -euo pipefail
NPROCS="${1:-4}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CASE="$ROOT/case"
command -v foamRun >/dev/null || { echo "Source OpenFOAM 14 first"; exit 2; }
cd "$ROOT"
python3 geometry/generate_stl.py
python3 scripts/calculate_flow.py
cd "$CASE"
rm -rf constant/polyMesh processor* postProcessing VTK [1-9]*
blockMesh > log.blockMesh 2>&1
surfaceFeatureExtract > log.surfaceFeatureExtract 2>&1
snappyHexMesh -overwrite > log.snappyHexMesh 2>&1
checkMesh -allGeometry -allTopology > log.checkMesh 2>&1
sed -i -E "s/^numberOfSubdomains[[:space:]]+[0-9]+;/numberOfSubdomains ${NPROCS};/" system/decomposeParDict
decomposePar -force > log.decomposePar 2>&1
mpirun -np "$NPROCS" foamRun -parallel > log.foamRun 2>&1
reconstructPar -latestTime > log.reconstructPar 2>&1
rm -rf processor*
foamToVTK -latestTime -fields '(U p)' > log.foamToVTK 2>&1 || true
cd "$ROOT"
python3 scripts/postprocess.py --skip-vtk-conversion
