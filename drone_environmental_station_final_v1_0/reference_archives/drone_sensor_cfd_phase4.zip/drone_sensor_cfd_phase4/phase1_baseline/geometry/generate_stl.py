#!/usr/bin/env python3
"""Generate a watertight triangulated flow boundary for Phase 1.

The external fluid domain is a 150 mm cube connected to two 10 mm ID tubes.
Sensor/PCB blocks are internal solid obstacles. Three STL patch files are
written: walls.stl, inlet.stl and outlet.stl.

No external CAD or boolean engine is required; only the Python standard
library is used. If trimesh is installed, an optional topology report is also
produced.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
from typing import Iterable, Sequence

Vec = tuple[float, float, float]
Tri = tuple[Vec, Vec, Vec]


def normal(a: Vec, b: Vec, c: Vec) -> Vec:
    ux, uy, uz = b[0]-a[0], b[1]-a[1], b[2]-a[2]
    vx, vy, vz = c[0]-a[0], c[1]-a[1], c[2]-a[2]
    nx, ny, nz = uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx
    mag = math.sqrt(nx*nx + ny*ny + nz*nz)
    return (0.0, 0.0, 0.0) if mag == 0 else (nx/mag, ny/mag, nz/mag)


def write_ascii_stl(path: Path, solid: str, triangles: Iterable[Tri]) -> None:
    with path.open('w', encoding='ascii') as f:
        f.write(f"solid {solid}\n")
        for a, b, c in triangles:
            nx, ny, nz = normal(a, b, c)
            f.write(f"  facet normal {nx:.12e} {ny:.12e} {nz:.12e}\n")
            f.write("    outer loop\n")
            for x, y, z in (a, b, c):
                f.write(f"      vertex {x:.12e} {y:.12e} {z:.12e}\n")
            f.write("    endloop\n  endfacet\n")
        f.write(f"endsolid {solid}\n")


def ring(x: float, radius: float, n: int) -> list[Vec]:
    return [(x, radius*math.cos(2*math.pi*i/n), radius*math.sin(2*math.pi*i/n)) for i in range(n)]


def square_ring(x: float, half: float, n: int) -> list[Vec]:
    pts = []
    for i in range(n):
        th = 2*math.pi*i/n
        cy, sz = math.cos(th), math.sin(th)
        scale = half / max(abs(cy), abs(sz))
        pts.append((x, scale*cy, scale*sz))
    return pts


def annulus(inner: Sequence[Vec], outer: Sequence[Vec], normal_positive_x: bool) -> list[Tri]:
    out: list[Tri] = []
    n = len(inner)
    for i in range(n):
        j = (i+1) % n
        # Two triangles per radial quad. Reverse order at x=0 for -x normal.
        if normal_positive_x:
            out += [(inner[i], outer[i], outer[j]), (inner[i], outer[j], inner[j])]
        else:
            out += [(inner[i], outer[j], outer[i]), (inner[i], inner[j], outer[j])]
    return out


def connect_rings(a: Sequence[Vec], b: Sequence[Vec], outward_radial: bool = True) -> list[Tri]:
    out: list[Tri] = []
    n = len(a)
    for i in range(n):
        j = (i+1) % n
        if outward_radial:
            out += [(a[i], b[i], b[j]), (a[i], b[j], a[j])]
        else:
            out += [(a[i], b[j], b[i]), (a[i], a[j], b[j])]
    return out


def disk(points: Sequence[Vec], centre: Vec, normal_positive_x: bool) -> list[Tri]:
    out: list[Tri] = []
    n = len(points)
    for i in range(n):
        j = (i+1) % n
        out.append((centre, points[i], points[j]) if normal_positive_x else (centre, points[j], points[i]))
    return out


def obstacle_box(center: Sequence[float], size: Sequence[float]) -> list[Tri]:
    """Closed box with normals directed into the obstacle (out of fluid)."""
    cx, cy, cz = center
    sx, sy, sz = (v/2 for v in size)
    v = [
        (cx-sx, cy-sy, cz-sz), (cx+sx, cy-sy, cz-sz),
        (cx+sx, cy+sy, cz-sz), (cx-sx, cy+sy, cz-sz),
        (cx-sx, cy-sy, cz+sz), (cx+sx, cy-sy, cz+sz),
        (cx+sx, cy+sy, cz+sz), (cx-sx, cy+sy, cz+sz),
    ]
    # Solid outward faces, then reverse every triangle for fluid-domain normals.
    faces = [
        (0,3,2),(0,2,1), (4,5,6),(4,6,7),
        (0,1,5),(0,5,4), (3,7,6),(3,6,2),
        (0,4,7),(0,7,3), (1,2,6),(1,6,5),
    ]
    return [(v[a], v[c], v[b]) for a,b,c in faces]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='../config/geometry.json')
    ap.add_argument('--output', default='../case/constant/triSurface')
    args = ap.parse_args()
    here = Path(__file__).resolve().parent
    cfg_path = (here / args.config).resolve()
    out_dir = (here / args.output).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    cfg = json.loads(cfg_path.read_text())

    L = cfg['box']['length_x']
    half = cfg['box']['width_y']/2
    diameter = cfg['tube']['internal_diameter']
    radius = diameter/2
    Lt = cfg['tube']['external_length']
    n = int(cfg['tube']['circle_segments'])
    if n < 24 or n % 8 != 0:
        raise ValueError('circle_segments must be >=24 and divisible by 8')

    inner0 = ring(0.0, radius, n)
    innerL = ring(L, radius, n)
    outer0 = square_ring(0.0, half, n)
    outerL = square_ring(L, half, n)
    inlet_ring = ring(-Lt, radius, n)
    outlet_ring = ring(L+Lt, radius, n)

    walls: list[Tri] = []
    walls += annulus(inner0, outer0, normal_positive_x=False)
    walls += annulus(innerL, outerL, normal_positive_x=True)
    walls += connect_rings(outer0, outerL, outward_radial=False)
    walls += connect_rings(inlet_ring, inner0, outward_radial=True)
    walls += connect_rings(innerL, outlet_ring, outward_radial=True)
    for item in cfg['sensors'].values():
        walls += obstacle_box(item['center'], item['size'])

    inlet = disk(inlet_ring, (-Lt, 0.0, 0.0), normal_positive_x=False)
    outlet = disk(outlet_ring, (L+Lt, 0.0, 0.0), normal_positive_x=True)

    write_ascii_stl(out_dir/'walls.stl', 'walls', walls)
    write_ascii_stl(out_dir/'inlet.stl', 'inlet', inlet)
    write_ascii_stl(out_dir/'outlet.stl', 'outlet', outlet)

    summary = {
        'walls_triangles': len(walls), 'inlet_triangles': len(inlet),
        'outlet_triangles': len(outlet), 'tube_radius_m': radius,
        'external_domain_x_m': [-Lt, L+Lt]
    }
    try:
        import trimesh
        meshes = [trimesh.load_mesh(str(out_dir/f), process=False) for f in ('walls.stl','inlet.stl','outlet.stl')]
        merged = trimesh.util.concatenate(meshes)
        merged.merge_vertices()
        summary.update({
            'combined_watertight': bool(merged.is_watertight),
            'combined_euler_number': int(merged.euler_number),
            'combined_components': int(len(merged.split(only_watertight=False)))
        })
    except Exception as exc:
        summary['topology_check'] = f'skipped: {exc}'
    (out_dir/'geometry_summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
