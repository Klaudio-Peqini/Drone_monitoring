This case is parameterized but requires the official OpenFOAM 14 CHT runtime adapter, region mesh generation and patch reconciliation before foamMultiRun. No numerical result is implied.
