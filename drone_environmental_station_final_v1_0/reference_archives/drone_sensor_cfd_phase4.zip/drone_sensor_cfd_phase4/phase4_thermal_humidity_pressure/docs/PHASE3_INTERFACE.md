# Phase 3 interface

Phase 4 exports `T`, `Yv`, RH and dew-point histories along the PM path. Dry particle diameters remain unchanged. Selected Phase 3 bins should be rerun on the thermal flow only if velocity-field or density changes exceed the declared comparison threshold. The missing Phase 2 numerical package and unexecuted Phase 3 cases remain dependencies.