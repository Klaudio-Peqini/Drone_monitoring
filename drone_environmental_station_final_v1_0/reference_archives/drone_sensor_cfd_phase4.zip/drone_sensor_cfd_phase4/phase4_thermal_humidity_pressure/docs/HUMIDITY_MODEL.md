# Humidity model

The baseline transports water-vapour mass fraction `Yv` as a bounded passive scalar with molecular diffusivity 2.5×10⁻⁵ m²/s. At inlet temperature `T`, relative humidity `RH` and total pressure `P`, the package computes saturation pressure with the Buck water correlation, vapour partial pressure `pv=RH·pws`, humidity ratio `w=0.621945 pv/(P-pv)` and `Yv=w/(1+w)`.

Local RH and dew point are post-processed from `T`, `P` and `Yv`. Condensation is not modelled; non-positive dew-point margin is a warning, not a liquid-film prediction.