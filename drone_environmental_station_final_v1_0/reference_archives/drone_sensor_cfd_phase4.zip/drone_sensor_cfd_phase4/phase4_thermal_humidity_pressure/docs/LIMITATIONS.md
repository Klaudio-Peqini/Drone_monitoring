# Limitations

The package contains provisional material properties and heat loads. It has no condensation, liquid film, hygroscopic PM growth, rotor downwash or external wind. Its OpenFOAM dictionaries are a version-14 adapter scaffold and must be reconciled with the exact installed official CHT tutorial before execution. No Phase 4 CFD result is bundled.