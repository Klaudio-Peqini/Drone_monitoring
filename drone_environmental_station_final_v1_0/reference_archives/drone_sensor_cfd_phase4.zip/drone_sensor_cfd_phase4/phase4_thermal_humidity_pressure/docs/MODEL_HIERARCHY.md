# Model hierarchy

1. **Forced CHT:** low-Mach `fluid` region plus `solid` regions with provisional heat sources.
2. **Buoyancy sensitivity:** add `p_rgh` only after Grashof/Rayleigh/Richardson screening.
3. **Humidity:** solve bounded water-vapour mass fraction `Yv` with `scalarTransport`; compute RH and dew point in post-processing.
4. **Pressure port:** compare port geometry and orientation using static, dynamic and total pressure.

Each level has an independent acceptance gate. The package never treats the existence of a case directory as numerical validation.