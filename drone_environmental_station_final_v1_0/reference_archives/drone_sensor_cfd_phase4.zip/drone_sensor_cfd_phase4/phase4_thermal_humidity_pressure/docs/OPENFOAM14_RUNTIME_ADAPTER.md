# OpenFOAM 14 runtime adapter

The repository is statically generated without an OpenFOAM installation. Version-specific thermophysical dictionaries and coupled-interface patch fields must therefore be taken from the **official tutorial installed with the exact OpenFOAM 14 build**.

1. Source OpenFOAM 14.
2. Run `scripts/preflight_openfoam14.sh`.
3. Run `scripts/bootstrap_openfoam14_case.sh` to copy an official CHT reference and record provenance.
4. Generate and inspect the Phase 4 solid STLs.
5. Create cell zones and region interfaces using the official `nonConformalCHT`/CHT workflow available in that installation.
6. Map Phase 1 flow geometry and reconcile patch names.
7. Copy the `fluid` and `solid` thermophysical dictionaries from the official tutorial and substitute values from `config/phase4.json`.
8. Add the provided heat-source `fvModels`, Yv field and function objects.
9. Run `checkMesh -allRegions`, serial smoke tests, energy/vapour closure checks and a serial/parallel comparison.
10. Only after these checks create `PREPARED_OPENFOAM14.ok` in the case.

This gate prevents a template from being mistaken for a numerically validated case.