# Pressure-sensor assessment

The pressure result is valid only at a defined static-pressure port or cavity. Compare baseline, jet-facing, normal-to-mean-flow and shielded arrangements. Report `p`, local `0.5 rho |U|²`, total pressure and `Bp=p_sensor-p_reference`. The analytical dynamic-pressure values are only screening bounds.