# Numerical verification

Required gates: flow imbalance <0.5%, energy closure <1%, vapour closure <0.5%, bounded Yv, physically reconstructed RH, <2% change between the two finest meshes and two smallest time steps, serial/parallel consistency and stable heat-path ranking. Any failed gate must propagate to `case_summary.csv` as a failure flag.