#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd "$(dirname "$0")" && pwd); ROOT=$(cd "$HERE/.." && pwd)
: "${WM_PROJECT_VERSION:?Source OpenFOAM 14 before running this script}"
if [[ "$WM_PROJECT_VERSION" != "14" ]]; then echo "Expected OpenFOAM 14, found $WM_PROJECT_VERSION" >&2; exit 2; fi
: "${FOAM_TUTORIALS:?FOAM_TUTORIALS is not set}"
mapfile -t CANDIDATES < <(find "$FOAM_TUTORIALS" -type d \( -name nonConformalCHT -o -name multiRegionHeater -o -name roomHeating \) 2>/dev/null | sort)
if (( ${#CANDIDATES[@]} == 0 )); then echo "No official CHT tutorial found under $FOAM_TUTORIALS" >&2; exit 3; fi
SRC=${CANDIDATES[0]}; DST="$ROOT/runtime_base/officialCHTReference"
rm -rf "$DST"; cp -a "$SRC" "$DST"
printf 'OpenFOAM version: %s\nOfficial tutorial source: %s\nCopied UTC: %s\n' "$WM_PROJECT_VERSION" "$SRC" "$(date -u +%FT%TZ)" > "$ROOT/runtime_base/official_tutorial_provenance.txt"
echo "Copied official reference: $SRC"
echo "Next: inspect docs/OPENFOAM14_RUNTIME_ADAPTER.md and run prepare_cases.py."
