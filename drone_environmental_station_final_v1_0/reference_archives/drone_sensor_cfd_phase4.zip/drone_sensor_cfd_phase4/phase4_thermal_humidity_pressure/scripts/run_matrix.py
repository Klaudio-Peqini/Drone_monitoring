#!/usr/bin/env python3
from __future__ import annotations
import argparse, subprocess
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--root',default='../generated_cases'); p.add_argument('--jobs',type=int,default=1); a=p.parse_args()
root=(Path(__file__).resolve().parent/a.root).resolve(); cases=sorted(x for x in root.iterdir() if x.is_dir() and (x/'PREPARED_OPENFOAM14.ok').exists())
if not cases: raise SystemExit('No runtime-approved cases. Complete OpenFOAM 14 adapter first.')
for c in cases: subprocess.run([str(Path(__file__).resolve().parent/'run_case.sh'),str(c)],check=True)
