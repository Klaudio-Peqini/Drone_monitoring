#!/usr/bin/env bash
set -euo pipefail
CASE=${1:?case}; NP=${2:-8}; CASE=$(readlink -f "$CASE")
[[ -f "$CASE/PREPARED_OPENFOAM14.ok" ]] || { echo "case not runtime-approved" >&2; exit 3; }
cd "$CASE"; decomposePar -allRegions -force > log.decomposePar 2>&1
mpirun -np "$NP" foamMultiRun -parallel > log.foamMultiRun.parallel 2>&1
reconstructPar -allRegions > log.reconstructPar 2>&1
