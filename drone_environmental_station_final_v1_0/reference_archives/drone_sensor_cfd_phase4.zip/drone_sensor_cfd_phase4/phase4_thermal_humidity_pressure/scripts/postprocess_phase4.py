#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math
from pathlib import Path
import numpy as np, pandas as pd

def response_time(t,y,frac):
    y0=float(y.iloc[0]); yf=float(y.iloc[-1]); target=y0+frac*(yf-y0)
    if yf>=y0: idx=np.where(y.to_numpy()>=target)[0]
    else: idx=np.where(y.to_numpy()<=target)[0]
    return float(t.iloc[idx[0]]) if len(idx) else math.nan

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--samples',required=True); ap.add_argument('--balances'); ap.add_argument('--case-id',required=True); ap.add_argument('--out',default='../results'); a=ap.parse_args()
    samples=Path(a.samples); out=(Path(__file__).resolve().parent/a.out).resolve(); (out/'csv').mkdir(parents=True,exist_ok=True); (out/'json').mkdir(parents=True,exist_ok=True); (out/'figures').mkdir(parents=True,exist_ok=True)
    if not samples.exists(): raise SystemExit('No sample file; CFD results were not generated')
    df=pd.read_csv(samples); required={'time_s','T_inlet_K','T_sensor_K','RH_inlet_pct','RH_sensor_pct','p_sensor_Pa','p_reference_Pa','U_sensor_m_s','dew_point_margin_K'}
    miss=required-set(df.columns)
    if miss: raise SystemExit(f'missing columns: {sorted(miss)}')
    t=df.time_s; metrics={"case_id":a.case_id,"BT_final_K":float((df.T_sensor_K-df.T_inlet_K).iloc[-1]),"BRH_final_pctpoint":float((df.RH_sensor_pct-df.RH_inlet_pct).iloc[-1]),"Bp_final_Pa":float((df.p_sensor_Pa-df.p_reference_Pa).iloc[-1]),"min_dew_point_margin_K":float(df.dew_point_margin_K.min()),"max_sensor_velocity_m_s":float(df.U_sensor_m_s.max())}
    for col,prefix in [('T_sensor_K','T'),('RH_sensor_pct','RH')]:
        for f in [.1,.5,.9,.95]: metrics[f'{prefix}_t{int(f*100)}_s']=response_time(t,df[col],f)
    pd.DataFrame([metrics]).to_csv(out/'csv'/f'{a.case_id}_metrics.csv',index=False)
    (out/'json'/f'{a.case_id}_metrics.json').write_text(json.dumps(metrics,indent=2)+'\n')
    try:
        import matplotlib.pyplot as plt
        for cols,name,ylabel in [(['T_inlet_K','T_sensor_K'],'sensor_temperature_response','Temperature [K]'),(['RH_inlet_pct','RH_sensor_pct'],'sensor_rh_response','RH [%]')]:
            fig,ax=plt.subplots();
            for c in cols: ax.plot(t,df[c],label=c)
            ax.set_xlabel('Time [s]'); ax.set_ylabel(ylabel); ax.legend(); fig.tight_layout(); fig.savefig(out/'figures'/f'{a.case_id}_{name}.png',dpi=180); plt.close(fig)
        fig,ax=plt.subplots(); ax.plot(df.U_sensor_m_s,df.p_sensor_Pa-df.p_reference_Pa,'.'); ax.set_xlabel('Sensor velocity [m/s]'); ax.set_ylabel('Pressure bias [Pa]'); fig.tight_layout(); fig.savefig(out/'figures'/f'{a.case_id}_pressure_bias_vs_flow.png',dpi=180); plt.close(fig)
    except Exception as e: print('plotting skipped:',e)
    print(metrics)
if __name__=='__main__': main()
