#!/usr/bin/env python3
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]/'generated_cases'
for c in sorted(x for x in root.iterdir() if x.is_dir()):
    status='runtime-approved' if (c/'PREPARED_OPENFOAM14.ok').exists() else 'parameterized-only'
    if (c/'log.foamMultiRun').exists(): status='run-log-present'
    print(f'{c.name},{status}')
