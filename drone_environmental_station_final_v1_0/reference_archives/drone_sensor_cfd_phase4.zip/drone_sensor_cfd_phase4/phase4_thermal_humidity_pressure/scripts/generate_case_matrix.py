#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path

def case(name, **kw):
    base=dict(flow_L_min=2.0, ambient_C=20.0, RH_pct=50.0, power='nominal', electronics=True,
              buoyancy=False, solar_W_m2=0.0, h_ext_W_m2K=25.0, port='baseline',
              test='steady', mesh='medium', dt_s=0.1, material='nominal', contact='nominal')
    base.update(kw); base['case_id']=name; return base

def build():
    out=[]
    out += [case('p4_reference_isothermal',electronics=False,power='off',test='isothermal_reference'),
            case('p4_forced_nominal')]
    for q in [1.0,5.0,10.0]: out.append(case(f'p4_flow_{q:g}Lmin',flow_L_min=q))
    for p in ['low','high']: out.append(case(f'p4_power_{p}',power=p))
    for t in [5.0,35.0]: out.append(case(f'p4_ambient_{t:g}C',ambient_C=t))
    for rh in [20.0,80.0]: out.append(case(f'p4_rh_{rh:g}pct',RH_pct=rh))
    out += [case('p4_solar_hot',solar_W_m2=600.0,h_ext_W_m2K=5.0,ambient_C=35.0),
            case('p4_low_external_convection',h_ext_W_m2K=5.0),
            case('p4_buoyancy_on',buoyancy=True),
            case('p4_temperature_step',test='temperature_step'),
            case('p4_humidity_step',test='humidity_step')]
    for port in ['facing_inlet_jet','normal_to_local_mean_flow','shielded_static_port']:
        out.append(case(f'p4_port_{port}',port=port,test='pressure_port'))
    out += [case('p4_mesh_coarse',mesh='coarse'),case('p4_mesh_fine',mesh='fine'),
            case('p4_dt_coarse',dt_s=0.2),case('p4_dt_fine',dt_s=0.05),
            case('p4_material_low_k',material='low_k'),case('p4_material_high_k',material='high_k'),
            case('p4_contact_low_R',contact='low_R'),case('p4_contact_high_R',contact='high_R')]
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',default='../config/case_matrix.csv'); a=ap.parse_args()
    target=(Path(__file__).resolve().parent/a.out).resolve(); target.parent.mkdir(parents=True,exist_ok=True)
    rows=build(); fields=list(rows[0])
    with target.open('w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=fields); wr.writeheader(); wr.writerows(rows)
    target.with_suffix('.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(f'wrote {len(rows)} cases to {target}')
if __name__=='__main__': main()
