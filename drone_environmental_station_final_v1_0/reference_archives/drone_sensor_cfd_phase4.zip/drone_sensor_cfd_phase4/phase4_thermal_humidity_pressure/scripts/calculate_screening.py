#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, math
from pathlib import Path

def pws_buck(Tc):
    return 611.21*math.exp((18.678-Tc/234.5)*(Tc/(257.14+Tc)))
def dewpoint_buck(pv):
    lo,hi=-80.0,80.0
    for _ in range(100):
        mid=(lo+hi)/2
        if pws_buck(mid)<pv: lo=mid
        else: hi=mid
    return (lo+hi)/2

def main():
    here=Path(__file__).resolve().parent; cfg=json.loads((here/'../config/phase4.json').resolve().read_text())
    out=(here/'../results/screening').resolve(); out.mkdir(parents=True,exist_ok=True)
    rho=cfg['air']['rho_kg_m3']; cp=cfg['air']['cp_J_kgK']; k=cfg['air']['k_W_mK']; nu=cfg['air']['nu_m2_s']; beta=cfg['air']['beta_1_K']
    alpha=k/(rho*cp); Pr=nu/alpha; D=cfg['geometry']['tube_id_m']; A=math.pi*D*D/4; L=cfg['geometry']['internal_box_m'][0]; V=math.prod(cfg['geometry']['internal_box_m']); g=9.81
    total_nom=sum(cfg['heat_sources_W_nominal'].values()); rows=[]
    for qL in cfg['flow_rates_L_min']:
        Q=qL/1000/60; U=Q/A; Re=U*D/nu; mdot=rho*Q; tau=V/Q; dyn=0.5*rho*U*U
        for level,mul in cfg['power_multipliers'].items():
            P=total_nom*mul; dTideal=P/(mdot*cp); dTscreen=max(cfg['expected_deltaT_for_screening_K'],min(dTideal,30.0))
            Gr=g*beta*dTscreen*L**3/nu**2; Ra=Gr*Pr; Ri=Gr/(Re**2) if Re else float('inf')
            rows.append(dict(flow_L_min=qL,power_level=level,total_power_W=P,Q_m3_s=Q,U_inlet_m_s=U,Re=Re,exchange_time_s=tau,mass_flow_kg_s=mdot,ideal_well_mixed_air_rise_K=dTideal,Pr=Pr,Gr=Gr,Ra=Ra,Ri=Ri,dynamic_pressure_Pa=dyn))
    with (out/'thermal_buoyancy_pressure_screening.csv').open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=rows[0].keys()); wr.writeheader(); wr.writerows(rows)
    psych=[]; P=cfg['atmospheric_pressure_Pa']
    for Tc in cfg['ambient_temperatures_C']:
        pws=pws_buck(Tc)
        for RH in cfg['relative_humidities_pct']:
            pv=RH/100*pws; w=0.621945*pv/(P-pv); Y=w/(1+w); Td=dewpoint_buck(pv)
            psych.append(dict(temperature_C=Tc,RH_percent=RH,p_sat_Pa=pws,p_vapour_Pa=pv,humidity_ratio_kg_kg_dry_air=w,water_vapour_mass_fraction=Y,dew_point_C=Td,dew_point_margin_K=Tc-Td))
    with (out/'psychrometric_inlet_conditions.csv').open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=psych[0].keys()); wr.writeheader(); wr.writerows(psych)
    summary={"note":"analytical screening only, not CFD results","Pr":Pr,"nominal_total_power_W":total_nom,"buoyancy_flag_rule":"investigate when Ri >= 0.1 or Ra is large enough for natural convection to compete","saturation_correlation":cfg['psychrometrics']}
    (out/'screening_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(out)
if __name__=='__main__': main()
