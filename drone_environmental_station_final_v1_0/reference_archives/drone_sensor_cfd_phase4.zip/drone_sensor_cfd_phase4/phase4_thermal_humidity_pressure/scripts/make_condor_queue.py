#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]; cases=sorted(x for x in (root/'generated_cases').iterdir() if x.is_dir())
out=root/'htcondor/cases.queue'; out.write_text('\n'.join(str(x.resolve()) for x in cases)+'\n'); print(out)
