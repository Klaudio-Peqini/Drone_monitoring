#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, shutil
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--matrix',default='../config/case_matrix.csv'); ap.add_argument('--out',default='../generated_cases'); a=ap.parse_args()
    here=Path(__file__).resolve().parent; matrix=(here/a.matrix).resolve(); out=(here/a.out).resolve(); template=(here/'../templates/cht_multiregion').resolve()
    if not matrix.exists(): raise SystemExit('Run generate_case_matrix.py first')
    out.mkdir(parents=True,exist_ok=True)
    with matrix.open() as f: rows=list(csv.DictReader(f))
    for r in rows:
        d=out/r['case_id'];
        if d.exists(): shutil.rmtree(d)
        shutil.copytree(template,d)
        (d/'case_metadata.json').write_text(json.dumps(r,indent=2)+'\n')
        (d/'RUNTIME_STATUS.md').write_text('This case is parameterized but requires the official OpenFOAM 14 CHT runtime adapter, region mesh generation and patch reconciliation before foamMultiRun. No numerical result is implied.\n')
    print(f'prepared {len(rows)} parameterized runtime stubs in {out}')
if __name__=='__main__': main()
