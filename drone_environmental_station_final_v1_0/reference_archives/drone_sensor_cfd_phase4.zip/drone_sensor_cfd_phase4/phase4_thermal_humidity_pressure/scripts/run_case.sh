#!/usr/bin/env bash
set -euo pipefail
CASE=${1:?usage: run_case.sh CASE}; CASE=$(readlink -f "$CASE")
[[ ${WM_PROJECT_VERSION:-} == 14 ]] || { echo "Source OpenFOAM 14" >&2; exit 2; }
[[ -f "$CASE/PREPARED_OPENFOAM14.ok" ]] || { echo "Refusing to run: missing PREPARED_OPENFOAM14.ok. Complete runtime adapter and mesh verification first." >&2; exit 3; }
cd "$CASE"; foamMultiRun > log.foamMultiRun 2>&1
