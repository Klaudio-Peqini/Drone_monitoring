#!/usr/bin/env bash
set -euo pipefail
need=(foamMultiRun foamRun foamPostProcess foamToC blockMesh snappyHexMesh splitMeshRegions decomposePar reconstructPar)
[[ ${WM_PROJECT_VERSION:-} == 14 ]] || { echo "Source OpenFOAM 14 first" >&2; exit 2; }
for x in "${need[@]}"; do command -v "$x" >/dev/null || { echo "missing: $x" >&2; exit 3; }; done
foamToC -solver fluid >/dev/null 2>&1 || echo "WARNING: verify fluid solver module with foamToC on this installation"
foamToC -solver solid >/dev/null 2>&1 || echo "WARNING: verify solid solver module with foamToC on this installation"
echo "OpenFOAM 14 executable preflight passed"
