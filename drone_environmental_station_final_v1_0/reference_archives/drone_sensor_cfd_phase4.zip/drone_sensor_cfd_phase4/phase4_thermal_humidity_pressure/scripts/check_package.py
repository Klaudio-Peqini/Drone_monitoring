#!/usr/bin/env python3
from __future__ import annotations
import json, py_compile, subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
required=['config/phase4.json','config/case_matrix.csv','results/screening/thermal_buoyancy_pressure_screening.csv','results/screening/psychrometric_inlet_conditions.csv','templates/cht_multiregion/system/controlDict','docs/OPENFOAM14_RUNTIME_ADAPTER.md','PHASE5_PROMPT.md']
missing=[x for x in required if not (root/x).exists()]
if missing: raise SystemExit(f'missing: {missing}')
for p in root.rglob('*.json'): json.loads(p.read_text())
for p in root.rglob('*.py'): py_compile.compile(str(p),doraise=True)
for p in root.rglob('*.sh'): subprocess.run(['bash','-n',str(p)],check=True)
# lightweight OpenFOAM brace check
for p in root.rglob('*'):
    if p.is_file() and ('templates/cht_multiregion' in str(p)) and p.suffix not in ['.stl','.md','.json']:
        try: txt=p.read_text()
        except UnicodeDecodeError: continue
        if txt.count('{')!=txt.count('}'): raise SystemExit(f'unbalanced braces: {p}')
print('Phase 4 static checks passed')
