#!/usr/bin/env python3
"""Generate watertight manufacturing-reference solid STLs for Phase 4.
These solids define intended regions; the runtime meshing adapter must verify interfaces in OpenFOAM 14.
"""
from __future__ import annotations
import json, math
from pathlib import Path
Vec=tuple[float,float,float]; Tri=tuple[Vec,Vec,Vec]
def nrm(a,b,c):
    u=[b[i]-a[i] for i in range(3)]; v=[c[i]-a[i] for i in range(3)]
    n=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]); m=math.sqrt(sum(x*x for x in n)); return tuple(x/m for x in n) if m else (0,0,0)
def write(path,name,tris):
    with path.open('w') as f:
        f.write(f'solid {name}\n')
        for a,b,c in tris:
            q=nrm(a,b,c); f.write(f' facet normal {q[0]:.9e} {q[1]:.9e} {q[2]:.9e}\n  outer loop\n')
            for p in (a,b,c): f.write(f'   vertex {p[0]:.9e} {p[1]:.9e} {p[2]:.9e}\n')
            f.write('  endloop\n endfacet\n')
        f.write(f'endsolid {name}\n')
def box(c,s):
    cx,cy,cz=c; hx,hy,hz=[x/2 for x in s]
    v=[(cx-hx,cy-hy,cz-hz),(cx+hx,cy-hy,cz-hz),(cx+hx,cy+hy,cz-hz),(cx-hx,cy+hy,cz-hz),(cx-hx,cy-hy,cz+hz),(cx+hx,cy-hy,cz+hz),(cx+hx,cy+hy,cz+hz),(cx-hx,cy+hy,cz+hz)]
    ids=[(0,3,2),(0,2,1),(4,5,6),(4,6,7),(0,4,7),(0,7,3),(1,2,6),(1,6,5),(0,1,5),(0,5,4),(3,7,6),(3,6,2)]
    return [(v[a],v[b],v[c]) for a,b,c in ids]
def annular_cylinder(x0,x1,ri,ro,n=96):
    def ring(x,r): return [(x,r*math.cos(2*math.pi*i/n),r*math.sin(2*math.pi*i/n)) for i in range(n)]
    ai,bi,ao,bo=ring(x0,ri),ring(x1,ri),ring(x0,ro),ring(x1,ro); t=[]
    for i in range(n):
        j=(i+1)%n
        t += [(ao[i],bo[i],bo[j]),(ao[i],bo[j],ao[j])]
        t += [(ai[i],bi[j],bi[i]),(ai[i],ai[j],bi[j])]
        t += [(ai[i],ao[j],ao[i]),(ai[i],ai[j],ao[j])]
        t += [(bi[i],bo[i],bo[j]),(bi[i],bo[j],bi[j])]
    return t
def main():
    root=Path(__file__).resolve().parents[1]; cfg=json.loads((root/'config/phase4.json').read_text()); base=json.loads((root.parent/'phase1_baseline/config/geometry.json').read_text())
    out=root/'templates/cht_multiregion/constant/triSurface'; out.mkdir(parents=True,exist_ok=True)
    L,W,H=cfg['geometry']['internal_box_m']; th=cfg['geometry']['wall_thickness_m']; r=cfg['geometry']['tube_id_m']/2; rt=r+cfg['geometry']['tube_wall_thickness_m']; Lt=cfg['geometry']['tube_external_length_m']
    solids={}
    # Export enclosure parts separately. Each STL is watertight; the OpenFOAM
    # runtime adapter merges them into the target enclosureSolid region after
    # interface and contact decisions are finalized.
    solids['enclosureYMinSolid']=box((L/2,-W/2-th/2,0),(L,th,H))
    solids['enclosureYMaxSolid']=box((L/2, W/2+th/2,0),(L,th,H))
    solids['enclosureZMinSolid']=box((L/2,0,-H/2-th/2),(L,W,th))
    solids['enclosureZMaxSolid']=box((L/2,0, H/2+th/2),(L,W,th))
    gap=2*rt
    for prefix,x in [('inletFace',-th/2),('outletFace',L+th/2)]:
        solids[prefix+'TopSolid']=box((x,0,(H+gap)/4),(th,W,(H-gap)/2))
        solids[prefix+'BottomSolid']=box((x,0,-(H+gap)/4),(th,W,(H-gap)/2))
        solids[prefix+'YMinSolid']=box((x,-(W+gap)/4,0),(th,(W-gap)/2,gap))
        solids[prefix+'YMaxSolid']=box((x, (W+gap)/4,0),(th,(W-gap)/2,gap))
    solids['inletTubeSolid']=annular_cylinder(-Lt-th,0,r,rt)
    solids['outletTubeSolid']=annular_cylinder(L,L+Lt+th,r,rt)
    # effective component solids from Phase 1 plus explicit heat blocks
    mapping={'pcbSolid':'pcb','pmSensorSolid':'pm_sensor','trhSensorSolid':'temperature_humidity','pressureSensorSolid':'pressure_sensor'}
    for name,key in mapping.items(): solids[name]=box(base['sensors'][key]['center'],base['sensors'][key]['size'])
    solids['batterySolid']=box((0.115,0,-0.055),(0.045,0.030,0.018))
    solids['processorSolid']=box((0.065,-0.010,-0.057),(0.012,0.012,0.003))
    solids['regulatorSolid']=box((0.085,-0.010,-0.057),(0.010,0.010,0.003))
    solids['communicationsSolid']=box((0.105,0.010,-0.057),(0.018,0.014,0.004))
    solids['pressurePortReference']=annular_cylinder(0.094,0.102,0.001,0.0015,48)
    summary={"status":"manufacturing-reference solids; OpenFOAM region/interface verification required","solids":{}}
    for name,tris in solids.items():
        path=out/f'{name}.stl'; write(path,name,tris); summary['solids'][name]={"triangles":len(tris)}
        try:
            import trimesh
            m=trimesh.load_mesh(path,process=True); summary['solids'][name].update(watertight=bool(m.is_watertight),components=len(m.split(only_watertight=False)))
        except Exception as e: summary['solids'][name]['topology_check']=f'skipped: {e}'
    (out/'phase4_geometry_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(out)
if __name__=='__main__': main()
