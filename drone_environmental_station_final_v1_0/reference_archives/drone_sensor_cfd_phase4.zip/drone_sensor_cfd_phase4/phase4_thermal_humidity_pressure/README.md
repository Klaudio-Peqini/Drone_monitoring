# Phase 4 — thermal, humidity and pressure framework

This directory implements the requested Phase 4 structure while preserving Phases 1–3. It provides analytical screening, geometry references, OpenFOAM 14 multi-region adapter templates, case-matrix automation, HTCondor support, post-processing schemas and verification gates.

## Static workflow

```bash
python3 scripts/generate_case_matrix.py
python3 scripts/calculate_screening.py
python3 geometry/generate_phase4_stl.py
python3 scripts/prepare_cases.py
python3 scripts/check_package.py
```

## OpenFOAM runtime workflow

```bash
source /opt/openfoam14/etc/bashrc
scripts/preflight_openfoam14.sh
scripts/bootstrap_openfoam14_case.sh
```

Then follow `docs/OPENFOAM14_RUNTIME_ADAPTER.md`. The run scripts deliberately refuse to execute until a case contains `PREPARED_OPENFOAM14.ok`.

## Results policy

Files in `results/screening/` are analytical pre-CFD estimates. No numerical CFD result is supplied. Phase 2 still lacks a runnable package, and Phase 3 remains a statically verified scaffold until run with OpenFOAM 14.